/*!  build: Vue Shop Vite 
     copyright: https://vue-admin-beautiful.com/shop-vite  
     time: 2025-04-10 15:52:22 
 */
import{d as m,r as s,g as n,c as v,o as f,i as o,j as c,t,a as e,m as i,v as b}from"./index-DMg0mq0e.js";const k={class:"error-container"},C={class:"error-content"},g={class:"pic-error"},x={class:"bullshit"},y={class:"bullshit-oops"},B={class:"bullshit-headline"},N={class:"bullshit-info"},E=m({__name:"404",setup(V){const a=s("抱歉！"),r=s("当前页面不存在。"),_=s("请检查您输入的网址是否正确，或点击下面的按钮返回首页。"),l=s("返回首页");return(j,w)=>{const d=n("vab-icon"),p=n("el-button"),u=n("router-link");return f(),v("div",k,[o("div",C,[o("div",g,[c(d,{class:"error-svg",icon:"404","is-custom-svg":""})]),o("div",x,[o("div",y,t(e(a)),1),o("div",B,t(e(r)),1),o("div",N,t(e(_)),1),c(u,{custom:"",to:"/"},{default:i(({navigate:h})=>[c(p,{type:"primary",onClick:h},{default:i(()=>[b(t(e(l)),1)]),_:2},1032,["onClick"])]),_:1})])])])}}});export{E as default};
